import { GameRoutes } from "./route/gameRoutes";

new GameRoutes();
