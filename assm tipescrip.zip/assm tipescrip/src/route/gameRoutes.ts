import { GameController } from "../controller/gameController";

export class GameRoutes {
    private game: GameController | undefined;

    constructor() {
        document.addEventListener("DOMContentLoaded", () => {
            this.game = new GameController();
            this.setupEventListeners();
        });
    }

    private setupEventListeners(): void {
        document.getElementById("reset-game")?.addEventListener("click", () => {
            location.reload(); // Chơi lại từ đầu
        });

        document.getElementById("cancel-game")?.addEventListener("click", () => {
            this.goToNameInput(); // Quay về nhập tên
        });
    }

    private goToNameInput(): void {
        // Thay thế nội dung trang bằng ô nhập tên
        document.body.innerHTML = `
            <h1>Nhập tên của bạn để bắt đầu</h1>
            <input type="text" id="player-name" placeholder="Nhập tên...">
            <button id="start-game">Bắt đầu</button>
        `;

        document.getElementById("start-game")?.addEventListener("click", () => {
            const name = (document.getElementById("player-name") as HTMLInputElement).value;
            if (name.trim().length >= 2) {
                location.reload(); // Load lại game sau khi nhập tên
            } else {
                alert("Tên không hợp lệ! Vui lòng nhập lại.");
            }
        });
    }
}
