export class BoardModel {
    board: string[][] = [];
    selectedCells: [number, number][] = [];

    constructor() {
        this.generateBoard();
    }

    generateBoard(): void {
        const icons: string[] = ["🐱", "🐶", "🐭", "🐹", "🐰", "🦊", "🐻", "🐼"];
        let pairs: string[] = [...icons, ...icons];
        pairs.sort(() => Math.random() - 0.5);
        this.board = [pairs.slice(0, 4), pairs.slice(4, 8), pairs.slice(8, 12), pairs.slice(12, 16)];
    }
}
