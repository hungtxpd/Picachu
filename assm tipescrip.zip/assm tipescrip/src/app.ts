class PikachuGame {
    private playerName: string = "";
    private board: string[][] = [];
    private selectedCells: [number, number][] = [];

    constructor() {
        this.initGame();
    }

    private initGame(): void {
        this.getPlayerName();
        this.generateBoard();
        this.renderBoard();
    }

    private getPlayerName(): void {
        let name: string | null = prompt("Nhập tên của bạn:");
        while (!name || name.length < 2 || /[^a-zA-Z0-9]/.test(name)) {
            name = prompt("Tên không hợp lệ! Nhập lại:");
        }
        this.playerName = name!;
    }

    private generateBoard(): void {
        const icons: string[] = ["🐱", "🐶", "🐭", "🐹", "🐰", "🦊", "🐻", "🐼"];
        let pairs: string[] = [...icons, ...icons];
        pairs.sort(() => Math.random() - 0.5);
        this.board = [pairs.slice(0, 4), pairs.slice(4, 8), pairs.slice(8, 12), pairs.slice(12, 16)];
    }

    private renderBoard(): void {
        const boardElement = document.getElementById("game-board");
        if (!boardElement) return;
        boardElement.innerHTML = "";

        this.board.forEach((row, i) => {
            row.forEach((cell, j) => {
                const cellElement = document.createElement("div");
                cellElement.classList.add("cell");
                cellElement.dataset.index = `${i}-${j}`;
                cellElement.addEventListener("click", () => this.handleCellClick(i, j));
                boardElement.appendChild(cellElement);
            });
        });
    }

    private handleCellClick(i: number, j: number): void {
        if (this.selectedCells.length < 2) {
            this.selectedCells.push([i, j]);
            this.updateBoardView();
            if (this.selectedCells.length === 2) {
                setTimeout(() => this.checkMatch(), 500);
            }
        }
    }

    private updateBoardView(): void {
        this.selectedCells.forEach(([i, j]) => {
            const cell = document.querySelector(`[data-index='${i}-${j}']`);
            if (cell) cell.textContent = this.board[i][j];
        });
    }

    private checkMatch(): void {
        const [[i1, j1], [i2, j2]] = this.selectedCells;
        if (this.board[i1][j1] === this.board[i2][j2]) {
            document.querySelector(`[data-index='${i1}-${j1}']`)!.classList.add("matched");
            document.querySelector(`[data-index='${i2}-${j2}']`)!.classList.add("matched");
        } else {
            document.querySelector(`[data-index='${i1}-${j1}']`)!.textContent = "";
            document.querySelector(`[data-index='${i2}-${j2}']`)!.textContent = "";
        }
        this.selectedCells = [];
    }
}

document.addEventListener("DOMContentLoaded", () => new PikachuGame());
document.getElementById("reset-game")!.addEventListener("click", () => location.reload());