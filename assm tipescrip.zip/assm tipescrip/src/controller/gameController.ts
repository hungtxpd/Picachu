import { BoardModel } from "../model/boardModel";

export class GameController {
    private boardModel: BoardModel;
    private playerName: string = "";

    constructor() {
        this.boardModel = new BoardModel();
        this.getPlayerName();
        this.renderBoard();
    }

    private getPlayerName(): void {
        let name: string | null = prompt("Nhập tên của bạn:");
        while (!name || name.length < 2 || /[^a-zA-Z0-9]/.test(name)) {
            name = prompt("Tên không hợp lệ! Nhập lại:");
        }
        this.playerName = name!;
    }

    private renderBoard(): void {
        const boardElement = document.getElementById("game-board");
        if (!boardElement) return;
        boardElement.innerHTML = "";

        this.boardModel.board.forEach((row, i) => {
            row.forEach((cell, j) => {
                const cellElement = document.createElement("div");
                cellElement.classList.add("cell");
                cellElement.dataset.index = `${i}-${j}`;
                cellElement.addEventListener("click", () => this.handleCellClick(i, j));
                boardElement.appendChild(cellElement);
            });
        });
    }

    private handleCellClick(i: number, j: number): void {
        if (this.boardModel.selectedCells.length < 2) {
            this.boardModel.selectedCells.push([i, j]);
            this.updateBoardView();
            if (this.boardModel.selectedCells.length === 2) {
                setTimeout(() => this.checkMatch(), 500);
            }
        }
    }

    private updateBoardView(): void {
        this.boardModel.selectedCells.forEach(([i, j]) => {
            const cell = document.querySelector(`[data-index='${i}-${j}']`);
            if (cell) cell.textContent = this.boardModel.board[i][j];
        });
    }

    private checkMatch(): void {
        const [[i1, j1], [i2, j2]] = this.boardModel.selectedCells;
        if (this.boardModel.board[i1][j1] === this.boardModel.board[i2][j2]) {
            document.querySelector(`[data-index='${i1}-${j1}']`)!.classList.add("matched");
            document.querySelector(`[data-index='${i2}-${j2}']`)!.classList.add("matched");
        } else {
            document.querySelector(`[data-index='${i1}-${j1}']`)!.textContent = "";
            document.querySelector(`[data-index='${i2}-${j2}']`)!.textContent = "";
        }
        this.boardModel.selectedCells = [];
    }
}
